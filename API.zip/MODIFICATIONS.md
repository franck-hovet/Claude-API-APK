# IA API v2.2 — ce qui a changé

Tout le code est dans `www/index.html`. Nouveaux plugins dans `package.json` : @capacitor/browser (liens) et @capacitor/filesystem (images).

## Étape à ne pas oublier : icône de notification
Les icônes sont dans `android-res/`. Le workflow GitHub doit les copier dans le projet Android,
après la commande `npx cap add android` (ou `npx cap sync`) et avant la compilation :

    cp -r android-res/* android/app/src/main/res/

Sans cette ligne, l'app fonctionne mais la notification garde le « i » dans un rond.
