# IA API v2.3

Tout le code est dans `www/index.html`.

## Étape obligatoire : icône de notification
Le workflow GitHub doit copier `android-res/` dans le projet Android, après `npx cap add android` et avant la compilation :

    cp -r android-res/* android/app/src/main/res/

## Changer le logo
Remplacer `assets/icon-only.png`, `assets/icon-foreground.png`, `assets/icon-background.png`
(et `assets/splash*.png` si besoin), puis régénérer `android-res/` (silhouette blanche du logo).

## Historique commun
Réglages « Mes clés API » > « Historique commun » : jeton GitHub classique avec la case « gist ».
Les clés API et les images ne sont jamais envoyées. Sur l'ordinateur : ouvrir `www/index.html`
dans un navigateur (ou le publier avec GitHub Pages), saisir le même jeton + le même ID de Gist.
