# IA API v2.3

Tout le code est dans `www/index.html`.

## Étape obligatoire : icône de notification
Le workflow GitHub doit copier `android-res/` dans le projet Android, après `npx cap add android` et avant la compilation :

    cp -r android-res/* android/app/src/main/res/

## Changer le logo
Remplacer `assets/icon-only.png`, `assets/icon-foreground.png`, `assets/icon-background.png`
(et `assets/splash*.png` si besoin), puis régénérer `android-res/` (silhouette blanche du logo).

## Historique commun
Réglages « Mes clés API » > « Historique commun » : jeton GitHub classique avec la case « gist ».
Les clés API et les images ne sont jamais envoyées. Sur l'ordinateur : ouvrir `www/index.html`
dans un navigateur (ou le publier avec GitHub Pages), saisir le même jeton + le même ID de Gist.

## v2.4 : code pour revoir une clé API
Dans le formulaire de clé : case « Pouvoir revoir cette clé plus tard, protégée par un code ».
Un code personnel (4 caractères ou plus) est demandé une seule fois ; ensuite un bouton « Voir » apparaît.
3 mauvais essais = blocage 30 s. Le code protège l'affichage dans l'app ; l'empreinte digitale
n'est pas gérée (elle demanderait un plugin natif supplémentaire).

## v2.5
- Nouveau logo : assets/ (icône, avant-plan, fond, splash) + icônes de notification dans android-res/.
- Widgets : texte/Markdown (titres, listes, tableaux), code (```widget-python:Titre …), CSV (tableau), HTML, SVG.

## v2.6
- Bouton appareil photo (prendre une photo à joindre au message).
- Appel vocal : bouton téléphone ; boucle « tu parles → l'IA répond à voix haute → tu reparles ».
- Micro : réinitialisation avant chaque écoute, coupure automatique si rien n'est dit, nouvel essai si le micro est occupé.
- Discussions « Notes (sans IA) » : notes datées (séparateur par jour + heure), modifiables et supprimables.

## v2.7
Le trombone ouvre un menu « Joindre » : Appareil photo, Photos, Fichier, Lien internet (page lue via r.jina.ai),
Coller le presse-papiers, Dessin à main levée. Le bouton appareil photo séparé a été retiré.
