# IA API v2.8

Tout le code est dans `www/index.html`.

## 1. Installer comme une MISE À JOUR (sans perdre les données)
Android accepte une mise à jour seulement si : même identifiant (`com.perso.iaapi`, inchangé), même signature
(`debug.keystore`, copié par le « postinstall » de package.json — ne jamais le supprimer ni le remplacer) et
un `versionCode` qui ne baisse pas. Le fichier `build-apk.example.yml` montre un workflow qui garantit les trois.
Les discussions sont dans le stockage de l'app : elles sont conservées lors d'une mise à jour.
Avant la toute première mise à jour : Paramètres (engrenage) > Exporter l'historique, par sécurité.
Si l'APK précédemment installé a été signé avec une autre clé, Android demandera UNE dernière désinstallation.

## 2. Étapes de build
- `android-res/` doit être copié dans `android/app/src/main/res/` (icône de notification).
- Nouveaux plugins dans package.json : browser, filesystem, clipboard (`npm install` suffit).

## 3. Historique commun
Réglages > « Historique commun » : colle seulement le jeton GitHub (classique, case « gist ») ; le Gist est retrouvé
tout seul. Case « Synchroniser aussi mes clés API » : chiffrées avec le jeton, dans le Gist privé.
